from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from tasks import models
from django.views.generic import ListView, DetailView, CreateView, View, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import TaskForm, TaskFilterForm, CommentForm
from django.http import HttpResponseRedirect
from django.core.exceptions import PermissionDenied
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

class TaskListView(ListView):
    model = models.Task
    context_object_name = "tasks"
    template_name = "tasks/task_list.html"

    def get_queryset(self):
        queryset = super().get_queryset()
        status = self.request.GET.get("status", "")
        
        if status:
            queryset = queryset.filter(status=status)
        return queryset

    def get_context_data(self, **kwargs):
        # Добавлен знак "="
        context = super().get_context_data(**kwargs)
        context["form"] = TaskFilterForm(self.request.GET)
        return context

def home(request):
    return render(request, "home.html")


def tables_list(request):
    tables = Table.objects.filter(is_active=True)

    return render(
        request,
        "tables_list.html",
        {"tables": tables}
    )


def table_detail(request, table_id):
    table = get_object_or_404(Table, id=table_id)

    return render(
        request,
        "table_detail.html",
        {"table": table}
    )


def clients_list(request):
    clients = Client.objects.all()

    return render(
        request,
        "clients_list.html",
        {"clients": clients}
    )


def client_detail(request, client_id):
    client = get_object_or_404(Client, id=client_id)

    bookings = Booking.objects.filter(client=client)

    return render(
        request,
        "client_detail.html",
        {
            "client": client,
            "bookings": bookings
        }
    )


def bookings_by_date(request):
    date = request.GET.get("date")
    bookings = None

    if date:
        bookings = Booking.objects.filter(date=date)

    return render(
        request,
        "bookings_by_date.html",
        {
            "bookings": bookings,
            "date": date
        }
    )



def table_bookings(request, table_id):
    table = get_object_or_404(Table, id=table_id)
    bookings = Booking.objects.filter(table=table)

    return render(
        request,
        "table_bookings.html",
        {
            "table": table,
            "bookings": bookings
        }
    )
