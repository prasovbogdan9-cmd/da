from django.contrib import admin
from ....table_booking.models import *

# Register your models here.

admin.site.register(Client)
admin.site.register(Table)
admin.site.register(Booking)
